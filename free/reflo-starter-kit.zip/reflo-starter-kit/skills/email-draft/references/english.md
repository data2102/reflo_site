# 영문 비즈니스 메일

## 구조 (한국어 메일보다 더 짧게)

```
Subject: {Action} — {Topic} (by {Date})

Hi {Name},

{One sentence: what you need and by when.}

{1-2 sentences of context.}

- {Item 1}
- {Item 2}

Could you confirm by {day, date}? Happy to adjust if that timing doesn't work.

Best regards,
{Name}
{Title}, {Company}
```

## 규칙
- 제목에 동사를 쓴다: `Request:`, `Action needed:`, `FYI:`, `Reminder:`
- 첫 문장에 요청. 배경 설명으로 시작하지 않는다.
- 문장 하나에 아이디어 하나. 접속사로 길게 잇지 않는다.
- 날짜는 `Thursday, March 12` 또는 `March 12 (Thu)`. `3/12`는 국가마다 해석이 달라 피한다.
- 시간은 타임존 포함: `10:00 KST (01:00 UTC)`

## 자주 쓰는 표현

| 상황 | 표현 |
|---|---|
| 요청 | Could you please send me ~ by {date}? |
| 부드러운 독촉 | Just following up on my email from {date}. |
| 강한 독촉 | We need this by {date} to keep the {project} on schedule. |
| 거절 | Unfortunately we won't be able to ~. What we can do instead is ~. |
| 사과 | I'm sorry for the delay on ~. Here's what we're doing: ~ |
| 일정 제안 | Would any of these work for you? 1) ~ 2) ~ 3) ~ |
| 확인 | Just to confirm: ~. Let me know if I've got that wrong. |
| 마무리 | Thanks in advance. / Let me know if you need anything else. |

## 쓰지 않는 표현
- `Dear Sir or Madam` (이름을 찾아 쓴다)
- `Please kindly ~` (중복 공손)
- `I would like to inform you that ~` (→ 바로 본론)
- `ASAP` (구체적 날짜로)

## 제출 형식
영문 본문 아래에 반드시 한국어 요약 3줄을 붙인다.
```
[한국어 요약]
- 요청 내용: ~
- 기한: ~
- 상대가 할 일: ~
```
